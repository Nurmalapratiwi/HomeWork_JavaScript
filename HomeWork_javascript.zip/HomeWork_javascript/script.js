const celciusInput = document.getElementById("celcius");
const fahrenhaitInput = document.getElementById("fahrenhait");
const kelvinInput = document.getElementById("kelvin");
const reamurInput = document.getElementById("reamur");

const inputs = document.getElementsByClassName("input");

for (let i = 0; i < inputs.length; i++) {
  let input = inputs[i];

  input.addEventListener("input", function (e) {
    let value = parseFloat(e.target.value);
    switch (e.target.name) {
      case "celcius":
        fahrenhaitInput.value = value * 1.8 + 32;
        kelvinInput.value = value + 273.15;
        reamurInput.value = value * 0.8;
        break;
      case "fahrenhait":
        celciusInput.value = (value - 32) / 1.8;
        kelvinInput.value = (value - 32) / 1.8 + 273.15;
        reamurInput.value = ((value - 32) / 1.8) * 0.8;
        break;
      case "kelvin":
        celciusInput.value = value - 273.15;
        fahrenhaitInput.value = (value - 32) / 1.8 + 32;
        reamurInput.value = (value - 273.15) * 0.8;
        break;
      case "reamur":
        celciusInput.value = value * 1.25;
        fahrenhaitInput.value = value * 2.25 + 32;
        kelvinInput.value = value * 1.25 + 273.15;
        break;
    }
  });
}
